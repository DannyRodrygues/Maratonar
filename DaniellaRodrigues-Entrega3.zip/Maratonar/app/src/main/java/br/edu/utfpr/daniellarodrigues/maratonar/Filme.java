package br.edu.utfpr.daniellarodrigues.maratonar;

import android.net.http.UrlRequest;

public class Filme {
    private String titulo;
    private String categoria;
    private boolean prioridade;
    private int classificacao;

    private Status status;

    public Filme(Status status, int classificacao, boolean prioridade, String categoria, String titulo) {
        this.status = status;
        this.classificacao = classificacao;
        this.prioridade = prioridade;
        this.categoria = categoria;
        this.titulo = titulo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public boolean isPrioridade() {
        return prioridade;
    }

    public void setPrioridade(boolean prioridade) {
        this.prioridade = prioridade;
    }

    public int getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(int classificacao) {
        this.classificacao = classificacao;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return titulo + "\n" +
                categoria + "\n" +
                prioridade + "\n" +
                classificacao + "\n" +
                status;
    }
}
