package br.edu.utfpr.daniellarodrigues.maratonar;

public enum Status {
    Assistido, //ordinal valor 0
    Nao_Assistido; // ordinal valor 1

}
