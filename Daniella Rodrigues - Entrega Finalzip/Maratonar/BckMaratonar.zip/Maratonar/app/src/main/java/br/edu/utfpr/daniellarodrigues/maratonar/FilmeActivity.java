package br.edu.utfpr.daniellarodrigues.maratonar;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;


public class FilmeActivity extends AppCompatActivity {

    private EditText txtEditTitulo, txtEditCategoria;
    private CheckBox ckBoxPrioridade;
    private RadioGroup rdBtnMaoUsada;
    private Spinner spinnerClassificacao;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filme);

        txtEditTitulo = findViewById(R.id.txtEditTitulo);
        txtEditCategoria = findViewById(R.id.txtEditCategoria);
        ckBoxPrioridade = findViewById(R.id.ckBoxPrioridade);
        rdBtnMaoUsada = findViewById(R.id.rdBtnMaoUsada);
        spinnerClassificacao = findViewById(R.id.spinnerClassificacao);

        //popularSpinner();
    }

   // private void popularSpinner(){
       // ArrayList<String> lista = new ArrayList<>();
        //lista.add(getString(R.string.selecione_um_item));
        //lista.add(getString(R.string.livre));
        //lista.add(getString(R.string._10_a_12_anos));
        //lista.add(getString(R.string._14_a_16_anos));
        //lista.add(getString(R.string.maiores_de_18_anos));

        //ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                                                       //android.R.layout.simple_list_item_1,
                                                       //lista);
        //spinnerClassificacao.setAdapter(adapter);
    //}
    public void limparCampos(View view){
        txtEditTitulo.setText(null);
        txtEditCategoria.setText(null);
        ckBoxPrioridade.setChecked(false);
        rdBtnMaoUsada.clearCheck();
        spinnerClassificacao.setSelection(0);

        txtEditTitulo.requestFocus();

        Toast.makeText(this,
                       R.string.as_entradas_foram_apagadas,
                        Toast.LENGTH_LONG).show();
    }

    public void salvarCampos(View view){
        String titulo = txtEditTitulo.getText().toString();
        if (titulo == null || titulo.trim().isEmpty()){
            Toast.makeText(this,
                           R.string.faltou_informar_o_titulo,
                           Toast.LENGTH_LONG).show();
            txtEditTitulo.requestFocus();

            return;

        }
        if (!titulo.matches("^[a-zA-ZÀ-ÿ\\s]+$")) { // valida pra que o usuario entre apenas com letras e nao numeros
            Toast.makeText(this,
                    R.string.o_titulo_deve_conter_apenas_letras,
                    Toast.LENGTH_LONG).show();
            txtEditTitulo.requestFocus();
            txtEditTitulo.setSelection(0, txtEditTitulo.getText().toString().length()); // vai selecionar ande deve ser corrigido
            return;
        }


        String categoria = txtEditCategoria.getText().toString();
        if (categoria == null || categoria.trim().isEmpty()){
            Toast.makeText(this,
                            R.string.faltou_informar_a_categoria,
                            Toast.LENGTH_LONG).show();
            txtEditCategoria.requestFocus();
            return;
        }
        if (!categoria.matches("^[a-zA-ZÀ-ÿ\\s]+$")) {
            Toast.makeText(this,
                    R.string.a_categoria_deve_conter_apenas_letras,
                    Toast.LENGTH_LONG).show();
            txtEditCategoria.requestFocus();
            txtEditCategoria.setSelection(0,txtEditCategoria.getText().toString().length()); // vai selecionar ande deve ser corrigido
            return;
        }

        int radioButtonId = rdBtnMaoUsada.getCheckedRadioButtonId();
            String maoUsada;
            if (radioButtonId == R.id.rdBtnAssistido){
                maoUsada = getString(R.string.assistido);
            } else if (radioButtonId == R.id.rdBtnNaoAssistido) {
                maoUsada = getString(R.string.nao_assistido);

            } else {
                Toast.makeText(this,
                               R.string.faltou_preencher_o_status,
                                Toast.LENGTH_LONG).show();
                return;
            }

         String classificacao = (String) spinnerClassificacao.getSelectedItem();
            if (classificacao == null){
                Toast.makeText(this,
                               R.string.selecione_a_classificacao_etaria,
                               Toast.LENGTH_LONG).show();
                return;
            }

        boolean prioridade = ckBoxPrioridade.isChecked();
        Toast.makeText(this,
                       getString(R.string.titulotoast) + titulo + "\n" +
                               getString(R.string.categoriatoast) + categoria + "\n" +
                               (prioridade ? getString(R.string.prioridade) : getString(R.string.nao_prioridade)) + "\n" +
                               getString(R.string.status_filme) + maoUsada + "\n" +
                               getString(R.string.classificacao_etariatoast) + classificacao,
                               Toast.LENGTH_LONG).show();
    }
}