package br.edu.utfpr.daniellarodrigues.maratonar;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;


public class FilmesActivity extends AppCompatActivity {

    private ListView lstVFilmes;
    private List<Filme> listaFilmes;
    private FilmeAdapter adapterFilme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filmes);

        lstVFilmes = findViewById(R.id.lstVFilmes);

        popularListaFilmes();
        // Configura o evento de clique nos itens da lista
        lstVFilmes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
             Filme filme = (Filme) lstVFilmes.getItemAtPosition(position);
                // Obtém o array de classificações do XML
                String[] classificacoes = getResources().getStringArray(R.array.classificacao);
                // Converte a classificação numérica para o texto correspondente
                String classificacaoTexto = classificacoes[filme.getClassificacao()];

                String mensagem = getString(R.string.titulotoast) + filme.getTitulo() + "\n" +
                        getString(R.string.categoriatoast) + filme.getCategoria() + "\n" +
                        (filme.isPrioridade() ? getString(R.string.prioridade) : getString(R.string.nao_prioridade)) + "\n" +
                        getString(R.string.status_filme) + filme.getStatus() + "\n" +
                        getString(R.string.classificacao_etariatoast) + classificacaoTexto;

                Toast.makeText(FilmesActivity.this, mensagem, Toast.LENGTH_LONG).show();
            }
        });
    }


   private void popularListaFilmes(){
        String[] filmes_titulo = getResources().getStringArray(R.array.filmes_titulo);
        String[] filmes_categoria = getResources().getStringArray(R.array.filmes_categoria);
        int[] filmes_prioridade = getResources().getIntArray(R.array.filmes_prioridade);
        int[] filmes_classificacao = getResources().getIntArray(R.array.filmes_classificacao);
        int[] filmes_status = getResources().getIntArray(R.array.filmes_status);

        Filme filme;
        boolean prioridade;
       Status status;

        Status[] statuss = Status.values();

        listaFilmes = new ArrayList<>();
        for (int cont = 0; cont < filmes_titulo.length; cont++){

            prioridade = (filmes_prioridade[cont]==1 ? true : false);
            status = statuss[filmes_status[cont]];

            filme = new Filme(status,
                    filmes_classificacao[cont],
                    prioridade,
                    filmes_categoria[cont],
                    filmes_titulo[cont]);
            listaFilmes.add(filme);
        }

        adapterFilme = new FilmeAdapter(this, listaFilmes);

        lstVFilmes.setAdapter(adapterFilme);
   }
}